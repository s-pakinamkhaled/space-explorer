const { getAPOD } = require('../services/apodService');
const axios = require('axios');

jest.mock('axios');

describe('NASA APOD API', () => {
  it('should return image data', async () => {
    const mockData = {
      data: {
        title: "Mock Title",
        explanation: "Mock Explanation",
        date: "2024-12-12",
        url: "http://example.com/image.jpg"
      }
    };
    axios.get.mockResolvedValue(mockData);

    const result = await getAPOD();
    expect(result.title).toBe("Mock Title");
    expect(result.explanation).toBe("Mock Explanation");
    expect(result.url).toBe("http://example.com/image.jpg");
  });
});
