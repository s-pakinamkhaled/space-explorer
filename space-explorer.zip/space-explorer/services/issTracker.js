const axios = require('axios');

const trackISS = async (req, res) => {
  try {
    const response = await axios.get('http://api.open-notify.org/iss-now.json');
    const { latitude, longitude } = response.data.iss_position;
    const timestamp = new Date(response.data.timestamp * 1000);
    res.json({
      timestamp: timestamp.toISOString(),
      location: { latitude, longitude }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to track ISS.' });
  }
};

module.exports = trackISS;
