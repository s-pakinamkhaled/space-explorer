const axios = require('axios');

const getAPOD = async () => {
  const response = await axios.get(
    'https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY'
  );
  return response.data;
};

module.exports = { getAPOD };
