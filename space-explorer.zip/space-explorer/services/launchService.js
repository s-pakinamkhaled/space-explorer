const axios = require('axios');

const fetchLaunches = async (req, res) => {
  try {
    const { search, status } = req.query;

    const response = await axios.get('https://ll.thespacedevs.com/2.2.0/launch/upcoming/', {
      params: {
        search: search || '',
        status: status || '',
        limit: 5
      }
    });

    if (response.data.results.length === 0) {
      return res.json({ message: "No upcoming launches found." });
    }

    const launches = response.data.results.map(launch => ({
      mission: launch.name,
      vehicle: launch.rocket.configuration.name,
      date: launch.net
    }));

    res.json({ launches });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch launch data.' });
  }
};

module.exports = fetchLaunches;
